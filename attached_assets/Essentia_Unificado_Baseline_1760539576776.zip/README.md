# Essentia — Unificado (Baseline)
Montado a partir de `ESSENTIA-COMPLETO.tar.gz` com **Purpose** como baseline.

## Copiados
{
  "purpose": true,
  "demo90": true,
  "mega": true,
  "routes_clean": true,
  "package_json": true,
  "vite_config": true,
  "index_css": true,
  "components_dir": true,
  "lib_dir": false
}

## Rodar
```bash
npm install
npm run dev
npm run build
```
Abra: `#/purpose`, `#/demo-90s`, `#/mega`.
