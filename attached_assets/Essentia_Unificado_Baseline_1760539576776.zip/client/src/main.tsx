import React from "react";
import { createRoot } from "react-dom/client";
import "./index.css";

const Purpose = React.lazy(() => import("./pages/purpose"));
const Demo90 = React.lazy(() => import("./pages/essentia-demo-90s"));
const Mega = React.lazy(() => import("./pages/essentia-mega"));

function useHashPath(defaultPath: string){
  const [path, setPath] = React.useState(window.location.hash.replace("#","") || defaultPath);
  React.useEffect(()=>{
    const onHash = () => setPath(window.location.hash.replace("#","") || defaultPath);
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [defaultPath]);
  return path;
}

const App = () => {
  const path = useHashPath("/purpose");
  const routes: Record<string, JSX.Element> = {
    "/purpose": <Purpose />,
    "/demo-90s": <Demo90 />,
    "/mega": <Mega />
  };
  return <React.Suspense fallback={<div style={{padding:20}}>Carregando…</div>}>{routes[path] || routes["/purpose"]}</React.Suspense>;
};

const root = document.getElementById("root");
if(root){ createRoot(root).render(<App />); } else {
  const el = document.createElement("div"); el.id="root"; document.body.appendChild(el); createRoot(el).render(<App />);
}
