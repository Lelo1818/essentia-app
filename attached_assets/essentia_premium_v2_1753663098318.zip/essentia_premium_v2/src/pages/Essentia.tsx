
import { portalsData } from '../data/portals-data';
import { PortalCard } from '../components/essentia/PortalCard';

export default function Essentia() {
  const handlePortalComplete = () => {
    console.log('Portal concluído!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 p-6">
      <div className="max-w-6xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-purple-800 mb-2">Essentia Premium V2</h1>
          <p className="text-purple-600">Sua jornada de autoconhecimento e propósito</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {portalsData.map((portal) => (
            <PortalCard 
              key={portal.id} 
              portal={portal} 
              onComplete={handlePortalComplete} 
            />
          ))}
        </div>
      </div>
    </div>
  );
}
