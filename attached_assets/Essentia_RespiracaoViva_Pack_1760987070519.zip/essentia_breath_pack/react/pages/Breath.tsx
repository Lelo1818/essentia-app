import React from "react";
import { BreathRitual } from "@/components/rituals/BreathRitual";

export default function BreathPage(){
  return (
    <div className="p-4 md:p-6">
      <BreathRitual
        videoSrc="/assets/inner-awakening.mp4"   // troque se quiser outro vídeo
        audioSrc="/assets/voice-446.mp3"        // opcional: sua voz/TTS
        onDone={()=> window.history.back()}
      />
    </div>
  )
}
