import React, { useRef, useState, useEffect } from "react";

/** BreathRitual 4-4-6
 * - Plays optional video background (muted, loop)
 * - Plays optional audio (TTS or 174Hz pad) after user tap
 * - Shows a breathing ring synced to 14s cycle
 */
export function BreathRitual({
  videoSrc,
  audioSrc,
  onDone
}: {
  videoSrc?: string;
  audioSrc?: string;
  onDone?: () => void;
}){
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [running, setRunning] = useState(false);

  useEffect(()=>{
    return ()=> { try { audioRef.current?.pause(); } catch {} };
  }, []);

  const start = async () => {
    setRunning(true);
    if(audioSrc){
      if(!audioRef.current){
        const a = new Audio(audioSrc);
        a.loop = true;
        a.preload = "auto";
        audioRef.current = a;
      }
      try { await audioRef.current.play(); } catch {}
    }
  };

  const stop = () => {
    setRunning(false);
    try { audioRef.current?.pause(); } catch {}
  };

  return (
    <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-[#0F1220]">
      <div className="relative min-h-[52vh]">
        {videoSrc ? (
          <video
            src={videoSrc}
            className="absolute inset-0 w-full h-full object-cover"
            autoPlay muted loop playsInline
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-tr from-[#0F1220] via-[#121935] to-[#0B0E19]" />
        )}
        <div className="absolute inset-0 bg-black/35" />
        <div className="relative z-10 flex flex-col items-center justify-center h-[52vh]">
          <BreathingRing running={running} />
          <div className="mt-6 flex gap-3">
            {!running ? (
              <button onClick={start} className="px-4 py-2 rounded-lg bg-white/90 text-[#0F1220] font-semibold">
                Começar 4‑4‑6
              </button>
            ) : (
              <button onClick={stop} className="px-4 py-2 rounded-lg bg-white/20 text-white font-semibold border border-white/30">
                Pausar
              </button>
            )}
            {onDone && (
              <button onClick={onDone} className="px-4 py-2 rounded-lg bg-[#6FD6C3] text-[#071613] font-semibold">
                Concluir
              </button>
            )}
          </div>
          {audioSrc && <div className="mt-2 text-xs text-white/70">Áudio ativo ao iniciar · toque para pausar</div>}
        </div>
      </div>
    </div>
  );
}

function BreathingRing({running}:{running:boolean}){
  // CSS animation: 14s cycle (4s expand, 4s hold, 6s contract)
  const k = running ? "breath-cycle 14s ease-in-out infinite" : "none";
  return (
    <div className="relative w-56 h-56">
      <style>{`
        @keyframes breath-cycle {
          0%   { transform: scale(1.00); filter: drop-shadow(0 0 0px rgba(143,168,255,.2)); }
          28.57% { transform: scale(1.12); } /* ~4s */
          57.14% { transform: scale(1.12); } /* hold to ~8s */
          100% { transform: scale(0.92); filter: drop-shadow(0 0 16px rgba(111,214,195,.25)); } /* ~14s */
        }
      `}</style>
      <svg viewBox="0 0 200 200" className="absolute inset-0" style={{animation: k}} aria-hidden>
        <defs>
          <radialGradient id="rg" cx="50%" cy="50%">
            <stop offset="0%" stopColor="#8AA8FF"/>
            <stop offset="100%" stopColor="#6FD6C3"/>
          </radialGradient>
        </defs>
        <circle cx="100" cy="100" r="78" fill="none" stroke="url(#rg)" strokeWidth="10" strokeOpacity="0.7"/>
        <circle cx="100" cy="100" r="90" fill="none" stroke="url(#rg)" strokeWidth="1" strokeOpacity="0.35"/>
      </svg>
      <div className="absolute inset-0 flex items-center justify-center text-white/90 select-none">
        {running ? (
          <div className="text-sm text-center leading-tight">
            <div>Respira 4</div>
            <div>Segura 4</div>
            <div>Solta 6</div>
          </div>
        ) : (
          <div className="text-sm text-center leading-tight opacity-80">
            <div>Pronto para começar</div>
            <div>Toque em “Começar 4‑4‑6”</div>
          </div>
        )}
      </div>
    </div>
  )
}
