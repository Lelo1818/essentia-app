import { useState, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency } from "@/lib/financial-utils";
import { queryClient } from "@/lib/queryClient";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  CreditCard, 
  PiggyBank,
  Target,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Zap,
  Medal,
  Trophy,
  Star,
  Wallet,
  BarChart3,
  User,
  Bell,
  Edit,
  Power,
  AlertTriangle,
  CheckCircle,
  Camera,
  Upload
} from "lucide-react";
import Income from "@/pages/income";
import ExpensesSimple from "@/pages/expenses-simple";
import Planning from "@/pages/planning";
import Goals from "@/pages/goals";
import Profile from "@/pages/profile";

// Alert Center Component
function AlertsCenter() {
  const [alerts, setAlerts] = useState([
    { id: 1, category: "Gastos Mensais", limit: 5000, current: 4267, active: true, type: "success" },
    { id: 2, category: "Alimentação", limit: 600, current: 571, active: true, type: "success" },
    { id: 3, category: "Transporte", limit: 500, current: 461, active: true, type: "success" },
    { id: 4, category: "Sobra Mínima", limit: 10000, current: 16333, active: true, type: "success" }
  ]);
  
  const [showEditor, setShowEditor] = useState(false);
  const [editingAlert, setEditingAlert] = useState(null);

  const createNewAlert = () => {
    setEditingAlert({
      id: Date.now(),
      category: "",
      limit: 0,
      current: 0,
      active: true,
      type: "info"
    });
    setShowEditor(true);
  };

  const editAlert = (alert) => {
    setEditingAlert(alert);
    setShowEditor(true);
  };

  const saveAlert = (alertData) => {
    if (editingAlert.id && alerts.find(a => a.id === editingAlert.id)) {
      setAlerts(alerts.map(a => a.id === editingAlert.id ? alertData : a));
    } else {
      setAlerts([...alerts, alertData]);
    }
    setShowEditor(false);
    setEditingAlert(null);
  };

  const toggleAlert = (id) => {
    setAlerts(alerts.map(a => a.id === id ? {...a, active: !a.active} : a));
  };

  const deleteAlert = (id) => {
    setAlerts(alerts.filter(a => a.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Central de Alertas</h2>
        <Button onClick={createNewAlert} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Novo Alerta
        </Button>
      </div>

      {/* Active Alerts */}
      <Card>
        <CardHeader>
          <CardTitle>Alertas Ativos ({alerts.filter(a => a.active).length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {alerts.map(alert => {
              const percentage = (alert.current / alert.limit) * 100;
              const status = percentage >= 100 ? "danger" : percentage >= 80 ? "warning" : "success";
              
              return (
                <div key={alert.id} className={`p-4 rounded-lg border ${
                  status === "danger" ? "bg-red-50 border-red-200" : 
                  status === "warning" ? "bg-yellow-50 border-yellow-200" :
                  "bg-green-50 border-green-200"
                }`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${
                        alert.active ? "bg-green-500" : "bg-gray-400"
                      }`} />
                      <h3 className="font-semibold">{alert.category}</h3>
                      <Badge 
                        variant={status === "success" ? "default" : "destructive"}
                        className={`${
                          status === "success" ? "bg-green-100 text-green-800" :
                          status === "warning" ? "bg-yellow-100 text-yellow-800" :
                          "bg-red-100 text-red-800"
                        }`}
                      >
                        {status === "success" && <CheckCircle className="w-3 h-3 mr-1" />}
                        {status === "warning" && <AlertTriangle className="w-3 h-3 mr-1" />}
                        {status === "danger" && <AlertTriangle className="w-3 h-3 mr-1" />}
                        {status === "success" ? "OK" : status === "warning" ? "ATENÇÃO" : "ALERTA"}
                      </Badge>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => editAlert(alert)}>
                        <Edit className="w-3 h-3 mr-1" />
                        Editar
                      </Button>
                      <Button 
                        size="sm" 
                        variant={alert.active ? "destructive" : "default"}
                        onClick={() => toggleAlert(alert.id)}
                      >
                        <Power className="w-3 h-3 mr-1" />
                        {alert.active ? "Desativar" : "Ativar"}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Atual: </span>
                      <span className="font-semibold">R$ {alert.current.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Limite: </span>
                      <span className="font-semibold">R$ {alert.limit.toLocaleString()}</span>
                    </div>
                  </div>
                  
                  <div className="mt-3">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Progresso</span>
                      <span>{percentage.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          status === "danger" ? "bg-red-500" :
                          status === "warning" ? "bg-yellow-500" :
                          "bg-green-500"
                        }`}
                        style={{ width: `${Math.min(percentage, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Alert Editor Modal */}
      {showEditor && (
        <AlertEditor
          alert={editingAlert}
          onSave={saveAlert}
          onCancel={() => {
            setShowEditor(false);
            setEditingAlert(null);
          }}
        />
      )}
    </div>
  );
}

// Alert Editor Component
function AlertEditor({ alert, onSave, onCancel }) {
  const [formData, setFormData] = useState(alert);

  const handleSave = () => {
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>{alert.id ? "Editar Alerta" : "Novo Alerta"}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Categoria</label>
            <select 
              className="w-full p-2 border rounded"
              value={formData.category}
              onChange={(e) => setFormData({...formData, category: e.target.value})}
            >
              <option value="">Selecione...</option>
              <option value="Gastos Mensais">Gastos Mensais</option>
              <option value="Alimentação">Alimentação</option>
              <option value="Transporte">Transporte</option>
              <option value="Entretenimento">Entretenimento</option>
              <option value="Sobra Mínima">Sobra Mínima</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Limite (R$)</label>
            <input 
              type="number"
              className="w-full p-2 border rounded"
              value={formData.limit}
              onChange={(e) => setFormData({...formData, limit: parseFloat(e.target.value) || 0})}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button onClick={handleSave} className="flex-1">
              Salvar Alerta
            </Button>
            <Button variant="outline" onClick={onCancel} className="flex-1">
              Cancelar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function FlowWorking() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [showIncomeModal, setShowIncomeModal] = useState(false);
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(false);

  // Set global demo mode
  useEffect(() => {
    window.isDemoMode = isDemoMode;
  }, [isDemoMode]);

  // Real financial data
  const { data: summary } = useQuery({
    queryKey: ['/api/financial-summary'],
    staleTime: 0,
    refetchInterval: 1000
  });

  const data = {
    totalIncome: summary?.totalIncome || 0,
    totalExpenses: summary?.totalExpenses || 0,
    balance: summary?.balance || 0,
    savings: 15420,
    investments: 8750,
    creditCards: 2100,
    goals: [
      { name: "Viagem Europa", progress: 57, current: 8500, target: 15000 },
      { name: "Reserva Emergência", progress: 48, current: 12000, target: 25000 }
    ],
    transactions: [
      { type: "income", desc: "Salário Principal", amount: 8500, date: "Hoje" },
      { type: "expense", desc: "Supermercado", amount: -450, date: "Ontem" },
      { type: "income", desc: "Freelance Design", amount: 1200, date: "2 dias" },
      { type: "expense", desc: "Gasolina", amount: -280, date: "3 dias" }
    ]
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      <div className="w-full px-4 sm:px-6 lg:px-8 py-4 sm:py-8 max-w-7xl mx-auto">
        
        {/* Mobile-First Navigation */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          
          {/* Mobile Header */}
          <div className="mb-4 sm:mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="p-2 sm:p-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl">
                  <Zap className="w-5 h-5 sm:w-8 sm:h-8 text-white" />
                </div>
                <div>
                  <h1 className="text-xl sm:text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    Flow
                  </h1>
                  <p className="text-xs sm:text-base text-slate-600 dark:text-slate-300 hidden sm:block">
                    Sua gestão financeira inteligente
                  </p>
                </div>
              </div>
              <Badge variant="secondary" className="bg-green-100 text-green-700 text-xs">
                Online
              </Badge>
            </div>
          </div>

          {/* Mobile Navigation Tabs with Visual Improvements */}
          <TabsList className="grid w-full grid-cols-5 mb-4 sm:mb-6 h-auto p-1 bg-white/80 backdrop-blur-sm border border-gray-200 shadow-lg rounded-xl">
            <TabsTrigger 
              value="dashboard" 
              className="flex flex-col gap-1 py-3 px-2 text-xs relative group hover:bg-blue-50 transition-all duration-200 data-[state=active]:bg-gradient-to-br data-[state=active]:from-blue-500 data-[state=active]:to-blue-600 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-blue-200"
            >
              <BarChart3 className="w-4 h-4 group-data-[state=active]:scale-110 transition-transform duration-200" />
              <span className="hidden sm:inline font-medium">Dashboard</span>
              <span className="sm:hidden font-medium">Home</span>
              <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
            </TabsTrigger>
            <TabsTrigger 
              value="income" 
              className="flex flex-col gap-1 py-3 px-2 text-xs relative group hover:bg-green-50 transition-all duration-200 data-[state=active]:bg-gradient-to-br data-[state=active]:from-green-500 data-[state=active]:to-green-600 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-green-200"
            >
              <TrendingUp className="w-4 h-4 group-data-[state=active]:scale-110 transition-transform duration-200" />
              <span className="font-medium">Renda</span>
              <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-green-500/10 to-emerald-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
            </TabsTrigger>
            <TabsTrigger 
              value="expenses" 
              className="flex flex-col gap-1 py-3 px-2 text-xs relative group hover:bg-red-50 transition-all duration-200 data-[state=active]:bg-gradient-to-br data-[state=active]:from-red-500 data-[state=active]:to-red-600 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-red-200"
            >
              <TrendingDown className="w-4 h-4 group-data-[state=active]:scale-110 transition-transform duration-200" />
              <span className="font-medium">Gastos</span>
              <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-red-500/10 to-orange-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
            </TabsTrigger>
            <TabsTrigger 
              value="goals" 
              className="flex flex-col gap-1 py-3 px-2 text-xs relative group hover:bg-purple-50 transition-all duration-200 data-[state=active]:bg-gradient-to-br data-[state=active]:from-purple-500 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-purple-200"
            >
              <Target className="w-4 h-4 group-data-[state=active]:scale-110 transition-transform duration-200" />
              <span className="font-medium">Metas</span>
              <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
            </TabsTrigger>
            <TabsTrigger 
              value="planning" 
              className="flex flex-col gap-1 py-3 px-2 text-xs relative group hover:bg-indigo-50 transition-all duration-200 data-[state=active]:bg-gradient-to-br data-[state=active]:from-indigo-500 data-[state=active]:to-indigo-600 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:shadow-indigo-200"
            >
              <PiggyBank className="w-4 h-4 group-data-[state=active]:scale-110 transition-transform duration-200" />
              <span className="font-medium">Plan.</span>
              <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-indigo-500/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="mt-0">
            {/* Estatísticas principais */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs sm:text-sm font-medium text-slate-600 mb-1">Receitas</p>
                      <p className="text-base sm:text-2xl lg:text-3xl font-bold text-green-600 truncate">
                        {formatCurrency(data.totalIncome)}
                      </p>
                      <p className="text-xs text-green-500 mt-1">+12.5%</p>
                    </div>
                    <div className="p-3 sm:p-4 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex-shrink-0 ml-3">
                      <TrendingUp className="w-5 h-5 sm:w-8 sm:h-8 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs sm:text-sm font-medium text-slate-600 mb-1">Gastos</p>
                      <p className="text-base sm:text-2xl lg:text-3xl font-bold text-red-600 truncate">
                        {formatCurrency(data.totalExpenses)}
                      </p>
                      <p className="text-xs text-red-500 mt-1">-8.2%</p>
                    </div>
                    <div className="p-3 sm:p-4 bg-gradient-to-br from-red-400 to-red-600 rounded-2xl flex-shrink-0 ml-3">
                      <TrendingDown className="w-5 h-5 sm:w-8 sm:h-8 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs sm:text-sm font-medium text-slate-600 mb-1">Saldo</p>
                      <p className="text-base sm:text-2xl lg:text-3xl font-bold text-blue-600 truncate">
                        {formatCurrency(data.balance)}
                      </p>
                      <p className="text-xs text-blue-500 mt-1">+23.1%</p>
                    </div>
                    <div className="p-3 sm:p-4 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex-shrink-0 ml-3">
                      <DollarSign className="w-5 h-5 sm:w-8 sm:h-8 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs sm:text-sm font-medium text-slate-600 mb-1">Investimentos</p>
                      <p className="text-base sm:text-2xl lg:text-3xl font-bold text-purple-600 truncate">
                        {formatCurrency(data.investments)}
                      </p>
                      <p className="text-xs text-purple-500 mt-1">+15.3%</p>
                    </div>
                    <div className="p-3 sm:p-4 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl flex-shrink-0 ml-3">
                      <Target className="w-5 h-5 sm:w-8 sm:h-8 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
              <Button 
                onClick={() => setShowIncomeModal(true)}
                className="h-16 flex flex-col gap-2 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 transform hover:scale-105 transition-all duration-200"
              >
                <Plus className="w-5 h-5" />
                <span className="text-xs">Nova Receita</span>
              </Button>
              <Button 
                onClick={() => setShowExpenseModal(true)}
                variant="outline" 
                className="h-16 flex flex-col gap-2 border-2 hover:bg-slate-50 transform hover:scale-105 transition-all duration-200"
              >
                <CreditCard className="w-5 h-5" />
                <span className="text-xs">Novo Gasto</span>
              </Button>
              <Button 
                onClick={() => setActiveTab("alerts")}
                className="h-16 flex flex-col gap-2 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 transform hover:scale-105 transition-all duration-200"
              >
                <Bell className="w-5 h-5" />
                <span className="text-xs">Alertas</span>
              </Button>
            </div>

            {/* Recent Transactions */}
            <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle>Transações Recentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {data.transactions.map((t, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-full ${t.type === 'income' ? 'bg-green-100' : 'bg-red-100'}`}>
                          {t.type === 'income' ? 
                            <ArrowUpRight className="w-4 h-4 text-green-600" /> : 
                            <ArrowDownRight className="w-4 h-4 text-red-600" />
                          }
                        </div>
                        <div>
                          <p className="font-medium text-slate-900 text-sm">{t.desc}</p>
                          <p className="text-xs text-slate-600">{t.date}</p>
                        </div>
                      </div>
                      <span className={`font-bold ${t.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                        {t.type === 'income' ? '+' : ''}{formatCurrency(Math.abs(t.amount))}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Income Tab */}
          <TabsContent value="income" className="mt-0">
            <Income />
          </TabsContent>

          {/* Expenses Tab */}
          <TabsContent value="expenses" className="mt-0">
            <ExpensesSimple />
          </TabsContent>

          {/* Goals Tab */}
          <TabsContent value="goals" className="mt-0">
            <Goals />
          </TabsContent>

          {/* Planning Tab */}
          <TabsContent value="planning" className="mt-0">
            <Planning />
          </TabsContent>

          {/* Alerts Tab - NEW FUNCTIONAL INTERFACE */}
          <TabsContent value="alerts" className="mt-0">
            <AlertsCenter />
          </TabsContent>

        </Tabs>

        {/* Income Modal */}
        {showIncomeModal && (
          <QuickIncomeModal onClose={() => setShowIncomeModal(false)} />
        )}

        {/* Expense Modal */}
        {showExpenseModal && (
          <QuickExpenseModal onClose={() => setShowExpenseModal(false)} />
        )}
      </div>
    </div>
  );
}

// Quick Income Modal with Camera
function QuickIncomeModal({ onClose }) {
  const [formData, setFormData] = useState({
    description: "",
    amount: "",
    frequency: "mensal"
  });
  const [showCamera, setShowCamera] = useState(false);
  const [stream, setStream] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const videoRef = useState(null);
  const canvasRef = useState(null);

  const handleSubmit = async () => {
    try {
      const response = await fetch('/api/incomes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          userId: 1,
          date: new Date().toISOString().split('T')[0]
        })
      });
      
      if (response.ok) {
        // Invalidate queries to update dashboard
        queryClient.invalidateQueries({ queryKey: ['/api/incomes'] });
        queryClient.invalidateQueries({ queryKey: ['/api/financial-summary'] });
        // Invalidação com key correta da API
        queryClient.removeQueries(['/api/financial-summary']);
        queryClient.invalidateQueries(['/api/financial-summary']);
        queryClient.invalidateQueries(['/api/incomes']);
        
        alert(`Nova receita adicionada!\n\n${formData.description}: ${formatCurrency(parseFloat(formData.amount))}\nFrequência: ${formData.frequency}`);
        onClose();
      }
    } catch (error) {
      alert('Erro ao adicionar receita');
    }
  };

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' }
      });
      setStream(mediaStream);
      setShowCamera(true);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      alert('Erro ao acessar câmera. Verifique as permissões.');
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const context = canvas.getContext('2d');
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0);
    
    const imageData = canvas.toDataURL('image/jpeg', 0.8);
    setCapturedImage(imageData);
    
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setShowCamera(false);
    
    // Analyze the captured image for income
    analyzeIncomeDocument();
  };

  const analyzeIncomeDocument = () => {
    setAnalyzing(true);
    
    setTimeout(() => {
      // Mock AI analysis result for income documents
      const result = {
        description: 'Pagamento Freelance - Design',
        amount: '2500.00',
        frequency: 'unica'
      };
      
      setFormData({
        description: result.description,
        amount: result.amount,
        frequency: result.frequency
      });
      setAnalyzing(false);
      alert('Documento analisado! Dados preenchidos automaticamente.');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <CardTitle className="text-green-600 flex items-center justify-between">
            Nova Receita
            <Button 
              size="sm" 
              onClick={startCamera}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Camera className="w-4 h-4 mr-1" />
              Foto
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Descrição</label>
            <input 
              type="text"
              className="w-full p-3 border rounded-lg"
              placeholder="Ex: Salário, Freelance..."
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Valor (R$)</label>
            <input 
              type="number"
              step="0.01"
              className="w-full p-3 border rounded-lg"
              placeholder="0,00"
              value={formData.amount}
              onChange={(e) => setFormData({...formData, amount: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Frequência</label>
            <select 
              className="w-full p-3 border rounded-lg"
              value={formData.frequency}
              onChange={(e) => setFormData({...formData, frequency: e.target.value})}
            >
              <option value="unica">Única</option>
              <option value="mensal">Mensal</option>
              <option value="semanal">Semanal</option>
              <option value="trimestral">Trimestral</option>
            </select>
          </div>

          {/* Camera Interface */}
          {showCamera && (
            <div className="space-y-4">
              <div className="relative bg-black rounded-lg">
                <video 
                  ref={videoRef}
                  autoPlay 
                  playsInline
                  className="w-full rounded-lg"
                  style={{ transform: 'scaleX(-1)' }}
                />
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                  <Button 
                    onClick={capturePhoto}
                    className="w-16 h-16 rounded-full bg-white hover:bg-gray-100 text-black"
                  >
                    <Camera className="w-8 h-8" />
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Captured Image Preview */}
          {capturedImage && (
            <div className="space-y-2">
              <img 
                src={capturedImage} 
                alt="Captured document" 
                className="w-full rounded-lg border max-h-32 object-cover"
              />
              {analyzing && (
                <div className="text-center py-2">
                  <div className="animate-spin w-6 h-6 border-2 border-green-400 border-t-transparent rounded-full mx-auto mb-2"></div>
                  <p className="text-sm">Analisando documento...</p>
                </div>
              )}
            </div>
          )}

          <canvas ref={canvasRef} style={{ display: 'none' }} />

          <div className="flex gap-3 pt-4">
            <Button 
              onClick={handleSubmit} 
              className="flex-1 bg-green-600 hover:bg-green-700"
              disabled={!formData.description || !formData.amount || analyzing}
            >
              {analyzing ? 'Processando...' : 'Adicionar Receita'}
            </Button>
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancelar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Enhanced Quick Expense Modal with AI Category Suggester and Camera
function QuickExpenseModal({ onClose }) {
  const [formData, setFormData] = useState({
    description: "",
    amount: "",
    category: "Outros"
  });
  const [aiSuggestion, setAiSuggestion] = useState(null);
  const [showSuggestion, setShowSuggestion] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [stream, setStream] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const videoRef = useState(null);
  const canvasRef = useState(null);

  const handleSubmit = async () => {
    try {
      const response = await fetch('/api/expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          userId: 1,
          date: new Date().toISOString().split('T')[0],
          recurring: false
        })
      });
      
      if (response.ok) {
        // Invalidação com key correta da API
        queryClient.removeQueries(['/api/financial-summary']);
        queryClient.invalidateQueries(['/api/financial-summary']);
        queryClient.invalidateQueries(['/api/expenses']);
        
        alert(`Novo gasto adicionado!\n\n${formData.description}: ${formatCurrency(parseFloat(formData.amount))}\nCategoria: ${formData.category}`);
        onClose();
      }
    } catch (error) {
      alert('Erro ao adicionar gasto');
    }
  };

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' }
      });
      setStream(mediaStream);
      setShowCamera(true);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      alert('Erro ao acessar câmera. Verifique as permissões.');
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const context = canvas.getContext('2d');
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0);
    
    const imageData = canvas.toDataURL('image/jpeg', 0.8);
    setCapturedImage(imageData);
    
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setShowCamera(false);
    
    // Analyze the captured image
    analyzeReceipt();
  };

  const analyzeReceipt = () => {
    setAnalyzing(true);
    
    setTimeout(() => {
      // Mock AI analysis result
      const result = {
        description: 'Supermercado Big',
        amount: '127.50',
        category: 'Alimentação'
      };
      
      setFormData({
        description: result.description,
        amount: result.amount,
        category: result.category
      });
      setAnalyzing(false);
      alert('Recibo analisado! Dados preenchidos automaticamente.');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <CardTitle className="text-red-600 flex items-center justify-between">
            Novo Gasto
            <Button 
              size="sm" 
              onClick={startCamera}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Camera className="w-4 h-4 mr-1" />
              Foto
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Descrição</label>
            <input 
              type="text"
              className="w-full p-3 border rounded-lg"
              placeholder="Ex: Supermercado, Gasolina..."
              value={formData.description}
              onChange={(e) => {
                const newDescription = e.target.value;
                setFormData({...formData, description: newDescription});
                
                // AI Category Suggestion
                if (newDescription.length > 3) {
                  const suggestion = getAICategory(newDescription);
                  setAiSuggestion(suggestion);
                  setShowSuggestion(true);
                } else {
                  setShowSuggestion(false);
                }
              }}
            />
            
            {/* AI Suggestion Box */}
            {showSuggestion && aiSuggestion && (
              <div className="mt-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-800">IA Sugeriu:</span>
                </div>
                <div className="text-sm text-blue-700 mb-2">
                  <strong>{aiSuggestion.category}</strong> ({aiSuggestion.confidence}% confiança)
                </div>
                <div className="text-xs text-blue-600 mb-3">
                  {aiSuggestion.reason}
                </div>
                <Button 
                  size="sm" 
                  onClick={() => {
                    setFormData({...formData, category: aiSuggestion.category});
                    setShowSuggestion(false);
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Aplicar Sugestão
                </Button>
              </div>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Valor (R$)</label>
            <input 
              type="number"
              step="0.01"
              className="w-full p-3 border rounded-lg"
              placeholder="0,00"
              value={formData.amount}
              onChange={(e) => setFormData({...formData, amount: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Categoria</label>
            <select 
              className="w-full p-3 border rounded-lg"
              value={formData.category}
              onChange={(e) => setFormData({...formData, category: e.target.value})}
            >
              <option value="Alimentação">Alimentação</option>
              <option value="Transporte">Transporte</option>
              <option value="Moradia">Moradia</option>
              <option value="Saúde">Saúde</option>
              <option value="Entretenimento">Entretenimento</option>
              <option value="Vestuário">Vestuário</option>
              <option value="Outros">Outros</option>
            </select>
          </div>

          {/* Camera Interface */}
          {showCamera && (
            <div className="space-y-4">
              <div className="relative bg-black rounded-lg">
                <video 
                  ref={videoRef}
                  autoPlay 
                  playsInline
                  className="w-full rounded-lg"
                  style={{ transform: 'scaleX(-1)' }}
                />
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                  <Button 
                    onClick={capturePhoto}
                    className="w-16 h-16 rounded-full bg-white hover:bg-gray-100 text-black"
                  >
                    <Camera className="w-8 h-8" />
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Captured Image Preview */}
          {capturedImage && (
            <div className="space-y-2">
              <img 
                src={capturedImage} 
                alt="Captured receipt" 
                className="w-full rounded-lg border max-h-32 object-cover"
              />
              {analyzing && (
                <div className="text-center py-2">
                  <div className="animate-spin w-6 h-6 border-2 border-blue-400 border-t-transparent rounded-full mx-auto mb-2"></div>
                  <p className="text-sm">Analisando recibo...</p>
                </div>
              )}
            </div>
          )}

          <canvas ref={canvasRef} style={{ display: 'none' }} />

          <div className="flex gap-3 pt-4">
            <Button 
              onClick={handleSubmit} 
              className="flex-1 bg-red-600 hover:bg-red-700"
              disabled={!formData.description || !formData.amount || analyzing}
            >
              {analyzing ? 'Processando...' : 'Adicionar Gasto'}
            </Button>
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancelar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}